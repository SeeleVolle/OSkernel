#include "syscall.h"
#include "elf.h"
#include "proc.h"
#include "defs.h"

extern void __ret_from_fork();

extern char ramdisk_start[];
extern char ramdisk_end[];
extern struct task_struct* current;
extern struct task_struct* task[NR_TASKS];
extern unsigned long  swapper_pg_dir[512] __attribute__((__aligned__(0x1000)));
extern uint64 load_program(struct task_struct* task);

void sys_call(struct pt_regs *regs, int sys_call_num){
    uint64 func = regs->x[17];

    //sys_getpid()
    if(func == 172){
        regs->x[10] = current->pid;
    }
    //sys_write()
    else if(func == 64){
        //fd(a0) = 1
        if(regs->x[10] == 1){
            //a1 = buf, a2 = count
            ((char *)(regs->x[11]))[regs->x[12]] = '\0';
            //a0 = 输出长度
            printk((char *)(regs->x[11])); 
            regs->x[10] = regs->x[12];
        }
    }
    //sys_clone()
    else if(func == 220){
        int free_index = -1;
        for(int i = 2; i < NR_TASKS; i++){
            if(task[i] == NULL){
                free_index = i;
                break;
            }
        }
        if(free_index == -1){
            printk("Task is full, sys_clone can't find a empty task\n");
            while(1);
        }
        /*
        1. 参考 task_init 创建一个新的 task, 将的 parent task 的整个页复制到新创建的 
        task_struct 页上(这一步复制了哪些东西?）。将 thread.ra 设置为 
        __ret_from_fork, 并正确设置 thread.sp
        */
        task[free_index] = (struct task_struct *)kalloc();
        uint64 *src = (uint64 *)current;
        uint64 *dst = (uint64 *)task[free_index];
        for(int i = 0; i < PGSIZE / 8; i++)
            dst[i] = src[i];

        task[free_index]->state = current->state;
        task[free_index]->pid = free_index;
        task[free_index]->counter = current->counter;
        task[free_index]->priority = current->priority;
        task[free_index]->thread_info = current->thread_info;
        
        uint64 current_sp = (uint64)regs;
        uint64 sscratch = csr_read(sscratch);
        uint64 sepc = csr_read(sepc);
        // printk("parent_sepc: %lx\n", sepc);
        // printk("parent_sscratch: %lx\n", sscratch);
        // printk("used_sepc: %lx\n", regs->sepc);
        // printk("used_sscratch: %lx\n", current->thread.sscratch);

        task[free_index]->thread.ra = __ret_from_fork;
        task[free_index]->thread.sp = (uint64)task[free_index] + PGSIZE - ((uint64)current + PGSIZE - (uint64)current_sp);
        for(int i = 0; i < 12; i++)
            task[free_index]->thread.s[i] = current->thread.s[i];
        task[free_index]->thread.sepc = regs->sepc;
        task[free_index]->thread.sstatus = current->thread.sstatus;
        task[free_index]->thread.sscratch = sscratch;
        
        /*
         2. 利用参数 regs 来计算出 child task 的对应的 pt_regs 的地址，
        并将其中的 a0, sp, sepc 设置成正确的值(为什么还要设置 sp?)
        */
        struct pt_regs* child_regs = (uint64)task[free_index] + PGSIZE - ((uint64)current + PGSIZE - (uint64)current_sp);
        child_regs->x[10] = 0;
        child_regs->x[2] = (uint64)task[free_index] + PGSIZE - ((uint64)current + PGSIZE - (uint64)current_sp);
        child_regs->sepc = regs->sepc;

        // printk("child_Regs->x[10] addr: %lx\n", (uint64)&child_regs->x[10]);

        /*、
        3. 为 child task 申请 user stack, 并将 parent task 的 user stack 
        数据复制到其中。
        */
        uint64 *user_st = (uint64 *)kalloc();

        src = (uint64 *)(USER_END - (uint64)PGSIZE);
        dst = (uint64 *)user_st;
        for(int i = 0; i < PGSIZE / 8; i++){
            dst[i] = src[i];
        }
        // printk("pgd: %lx\n", (uint64)task[free_index]->pgd);
        // printk("satp: %lx\n", (((uint64)task[free_index]->pgd - PA2VA_OFFSET) >> 12) | ((uint64)0x8 << 60));
        // printk("user_stack_start: %lx\n",  (uint64)USER_END - PGSIZE);
        // printk("user_stack_end: %lx\n",  (uint64)USER_END);
        // printk("user_stack_pm: %lx\n", (uint64)user_st - PA2VA_OFFSET);


        /*4. 为 child task 分配一个根页表，并仿照 setup_vm_final 来创建内核空间的映射*/
        task[free_index]->pgd = (pagetable_t)kalloc();
        memset(task[free_index]->pgd, 0, PGSIZE);
         for(int j = 0; j < PGSIZE / 8; j++){
            task[free_index]->pgd[j]=swapper_pg_dir[j];
        }

        create_mapping(task[free_index]->pgd, (uint64)USER_END - PGSIZE, (uint64)user_st - PA2VA_OFFSET, PGSIZE, 23);

        /*5. 根据 parent task 的页表和 vma 来分配并拷贝 child task 在用户态会用到的内存*/
        
        task[free_index]->vma_cnt = current->vma_cnt;
        for(int i = 0; i < current->vma_cnt; i++){
            task[free_index]->vmas[i].vm_start = current->vmas[i].vm_start;
            task[free_index]->vmas[i].vm_end = current->vmas[i].vm_end;
            task[free_index]->vmas[i].vm_flags = current->vmas[i].vm_flags;
            task[free_index]->vmas[i].vm_content_offset_in_file = current->vmas[i].vm_content_offset_in_file;
            task[free_index]->vmas[i].vm_content_size_in_file = current->vmas[i].vm_content_size_in_file;
            
            uint64 page_num = (current->vmas[i].vm_start - PGROUNDDOWN((uint64)current->vmas[i].vm_start) + current->vmas[i].vm_content_size_in_file + PGSIZE - 1) / PGSIZE;
            // printk("pid: %lx, current_pgd: %lx\n", current->pid, current->pgd);

            uint64 uapp = alloc_pages(page_num);
            memset(uapp, 0, page_num*PGSIZE);
            int annom_flag = current->vmas[i].vm_flags & VM_ANONYM;

            int *global_variable = (int *)(0x0000000000011944);
            // printk("global_variable[parent]: %d\n", *global_variable);
            if(!annom_flag){
                for(int t = 0; t < page_num; t++){
                    uint64* src = (uint64*)(PGROUNDDOWN((uint64)current->vmas[i].vm_start) + t * PGSIZE);
                    uint64* src2 = (uint64*)(ramdisk_start + t * PGSIZE + current->vmas[i].vm_content_offset_in_file);
                    uint64* dst = (uint64*)(uapp + t * PGSIZE);
                    for (int k = 0; k < PGSIZE / 8; k++) {
                        dst[k] = src[k]; 
                    }
                }
                create_mapping(task[free_index]->pgd, PGROUNDDOWN((uint64)current->vmas[i].vm_start), uapp - PA2VA_OFFSET, PGSIZE*page_num, current->vmas[i].vm_flags | 0b10001);
                // printk("uapp: %lx\n", (uint64)PGROUNDDOWN((uint64)current->vmas[i].vm_start));
                // printk("uapp_end: %lx\n", (uint64)(PGROUNDDOWN((uint64)current->vmas[i].vm_start) + PGSIZE * page_num));
                // printk("page_num: %ld\n", page_num);
            }
        }

        /*6. 返回子 task 的 pi*/
        regs->x[10] = free_index;
        printk("[S] New task: %ld\n", free_index);
    }
    return;
}
