//arch/riscv/kernel/proc.c
#include "proc.h"
#include "mm.h"
#include "defs.h"
#include "rand.h"
#include "printk.h"
#include "test.h"
#include "elf.h"
#include "string.h"


//arch/riscv/kernel/proc.c

extern char _stext[];
extern char _srodata[];
extern char _sdata[];
extern char ramdisk_start[];
extern char ramdisk_end[];
extern unsigned long  swapper_pg_dir[512] __attribute__((__aligned__(0x1000)));


extern void __dummy();
extern void __switch_to(struct task_struct* prev, struct task_struct* next);

struct task_struct* idle;           // idle process
struct task_struct* current;        // 指向当前运行线程的 `task_struct`
struct task_struct* task[NR_TASKS]; // 线程数组, 所有的线程都保存在此

/**
 * new content for unit test of 2023 OS lab2
*/
extern uint64 task_test_priority[]; // test_init 后, 用于初始化 task[i].priority 的数组
extern uint64 task_test_counter[];  // test_init 后, 用于初始化 task[i].counter  的数组

uint64 load_program(struct task_struct* task) {
    Elf64_Ehdr* ehdr = (Elf64_Ehdr*)ramdisk_start;

    uint64_t phdr_start = (uint64_t)ehdr + ehdr->e_phoff;
    int phdr_cnt = ehdr->e_phnum;
  
    Elf64_Phdr* phdr;
    int load_phdr_cnt = 0;
    for (int i = 0; i < phdr_cnt; i++) {
        phdr = (Elf64_Phdr*)(phdr_start + sizeof(Elf64_Phdr) * i);
        if (phdr->p_type == PT_LOAD) {
        //     // alloc space and copy content
            uint64 page_num = (phdr->p_vaddr - PGROUNDDOWN((uint64)phdr->p_vaddr) + phdr->p_memsz + PGSIZE - 1) / PGSIZE;
            // uint64 uapp = alloc_pages(page_num);
            // memset(uapp, 0, page_num*PGSIZE);
            // for(int t = 0; t < page_num; t++){
            //     uint64* src = (uint64*)(ramdisk_start + t * PGSIZE + phdr->p_offset);
            //     uint64* dst = (uint64*)(uapp + t * PGSIZE + phdr->p_vaddr - PGROUNDDOWN((uint64)phdr->p_vaddr));
            //     for (int k = 0; k < PGSIZE / 8; k++) {
            //         dst[k] = src[k]; 
            //     }
            // }
          	// // do mapping  X|W|R|V
            // create_mapping(task->pgd, PGROUNDDOWN((uint64)phdr->p_vaddr), uapp - PA2VA_OFFSET, PGSIZE*page_num, 
            // ((phdr->p_flags & PF_X) << 3) | ((phdr->p_flags & PF_W) << 1) | ((phdr->p_flags & PF_R) >> 1) | 0b10001);
            do_mmap(task, (uint64)phdr->p_vaddr, PGSIZE*page_num,
                    ((phdr->p_flags & PF_X) << 3) | ((phdr->p_flags & PF_W) << 1) | ((phdr->p_flags & PF_R) >> 1), phdr->p_offset, phdr->p_memsz);
            // printk("pid: %lx, task_pgd: %lx\n", task->pid, task->pgd);
        }
    }
  
    // allocate user stack and do mapping
    // code...
    do_mmap(task, (uint64)USER_END - PGSIZE, PGSIZE, 
            0x2 | 0x4 | 0x1, 0, PGSIZE);
    // create_mapping(task->pgd, USER_END - PGSIZE, (uint64)kalloc - PA2VA_OFFSET, PGSIZE, 23);
  
    // following code has been written for you
    // set user stack
    // pc for the user program
    task->thread.sepc = ehdr->e_entry;
    // sstatus bits set
    task->thread.sstatus = (1ULL << 5) + (1ULL << 18);
    // user stack for user program
    task->thread.sscratch = USER_END;
}


void task_init() {
  
    test_init(NR_TASKS);
    // 1. 调用 kalloc() 为 idle 分配一个物理页
    idle = (struct task_struct *)kalloc();
    // 2. 设置 state 为 TASK_RUNNING;
    idle->state = TASK_RUNNING;
    // 3. 由于 idle 不参与调度 可以将其 counter / priority 设置为 0
    idle->counter = 0;
    idle->priority = 0;
    // 4. 设置 idle 的 pid 为 0
    idle->pid = 0;
    idle->pgd=swapper_pg_dir;
    // 5. 将 current 和 task[0] 指向 idle
    task[0] = idle;
    current = idle;
    /* YOUR CODE HERE */

    // 1. 参考 idle 的设置, 为 task[1]進行初始化，其余赋值成NULL
    for(int i = 1; i < NR_TASKS; i++){
        if(i != 1){
            task[i] = NULL;
            continue;
        }
        task[i] = (struct task_struct *)kalloc();
        task[i]->state = TASK_RUNNING;
        task[i]->pid = i;
        task[i]->counter = task_test_counter[i];
        task[i]->priority = task_test_priority[i];
        task[i]->thread.ra = (uint64)__dummy;
        task[i]->thread.sp = (uint64)task[i] + 4096;    

        task[i]->pgd = (pagetable_t)kalloc();
        memset(task[i]->pgd , 0, PGSIZE);
        for(int j = 0; j < PGSIZE / 8; j++){
            task[i]->pgd[j]=swapper_pg_dir[j];
        }

        load_program(task[i]);
        printk("[S] Initialized: pid: %d, priority: %d, counter: %d\n", task[i]->pid, task[i]->priority, task[i]->counter);

        // uint64 uapp = alloc_pages((PGROUNDUP((uint64)uapp_end) - (uint64)uapp_start) / PGSIZE);
        // for(int t = 0; t < (PGROUNDUP((uint64)uapp_end) - (uint64)uapp_start) / PGSIZE; t++){
        //     uint64* src = (uint64*)(uapp_start + t * PGSIZE);
        //     uint64* dst = (uint64*)(uapp + t * PGSIZE);
        //     for (int k = 0; k < PGSIZE / 8; k++) {
        //         dst[k] = src[k];
        //     }
        // }
        
        // // if(i == 1)
        // // {
        // //     printk("uapp_start: %lx\n", (uint64)uapp_start);
        // //     printk("uapp_end: %lx\n", (uint64)uapp_end);
        // // }

        // create_mapping(task[i]->pgd , (uint64)USER_START,  (uint64)uapp -(uint64)PA2VA_OFFSET, (uint64)uapp_end - (uint64)uapp_start, 31);
        // create_mapping(task[i]->pgd , (uint64)USER_END - (uint64)PGSIZE, (uint64)kalloc() - (uint64)PA2VA_OFFSET, (uint64)PGSIZE, 23);

        // // if(i == 1)
        // // {
        // //     printk("task[i]->pgd: %lx\n", (((uint64)(task[i]->pgd))));
        // //     printk("task[i]->pgd: %lx\n", (uint64)(PA2VA_OFFSET));
        // //     printk("task[i]->pgd: %lx\n", (uint64)task[i]->pgd - (uint64)PA2VA_OFFSET);
        // //     printk("task[i]->pgd: %lx\n", (((uint64)((uint64)task[i]->pgd - (uint64)PA2VA_OFFSET) >> 12)));
        // // }


        // task[i]->thread.sepc = USER_START;
        // task[i]->thread.sstatus = (1ULL << 5) + (1ULL << 18);
        // task[i]->thread.sscratch = USER_END;
    }

    printk("...proc_init done!\n");
}

void do_mmap(struct task_struct *task, uint64 addr, uint64 length, uint64 flags, uint64 vm_content_offset_in_file, uint64 vm_content_size_in_file)
{
    task->vma_cnt++;
    task->vmas[task->vma_cnt-1].vm_start = addr;
    task->vmas[task->vma_cnt-1].vm_end = PGROUNDDOWN(addr) + length;
    task->vmas[task->vma_cnt-1].vm_flags = flags;
    task->vmas[task->vma_cnt-1].vm_content_offset_in_file = vm_content_offset_in_file;
    task->vmas[task->vma_cnt-1].vm_content_size_in_file = vm_content_size_in_file;

}

struct vm_area_struct *find_vma(struct task_struct *task, uint64 addr)
{
    int vma_index = -1;
    for(int i = 0; i < task->vma_cnt; i++){
        if(PGROUNDDOWN(task->vmas[i].vm_start) <= addr && task->vmas[i].vm_end >= addr)
        {
            vma_index = i;
            break;
        }
    }
    if(vma_index == -1){
        printk("Not found the vma in the task: %lx\n", (uint64)addr);
        printk("addr: %lx", (uint64)addr);
        while(1);
        return NULL;
    }
    return &(task->vmas[vma_index]);
}

void do_page_fault(struct pt_regs *regs){
     //1. 通过 stval 获得访问出错的虚拟内存地址（Bad Address）
     uint64 bad_addr = csr_read(stval);
     //2. 通过 find_vma() 查找 Bad Address 是否在某个 vma 中
     struct vm_area_struct* vma = find_vma(current, bad_addr);
    //  if(vma){
    //     uint64 page_num = (vma->vm_start - PGROUNDDOWN((uint64)vma->vm_start) + vma->vm_content_size_in_file + PGSIZE - 1) / PGSIZE;
    //     printk("pid: %lx, current_pgd: %lx\n", current->pid, current->pgd);

    //     uint64 uapp = alloc_pages(page_num);
    //     // printk("uapp: %lx", (uint64)uapp);

    //     memset(uapp, 0, page_num*PGSIZE);
    //     int annom_flag = vma->vm_flags & VM_ANONYM;

    //     if(!annom_flag){
    //         for(int t = 0; t < page_num; t++){
    //             uint64* src = (uint64*)(ramdisk_start + t * PGSIZE + vma->vm_content_offset_in_file);
    //             uint64* dst = (uint64*)(uapp + t * PGSIZE + vma->vm_start  - PGROUNDDOWN((uint64)vma->vm_start));
    //             for (int k = 0; k < PGSIZE / 8; k++) {
    //                 dst[k] = src[k]; 
    //             }
    //         }
    //         create_mapping(current->pgd, PGROUNDDOWN((uint64)vma->vm_start), uapp - PA2VA_OFFSET, PGSIZE*page_num, vma->vm_flags | 0b10001);
    //    }
    //    else{
    //         create_mapping(current->pgd, PGROUNDDOWN((uint64)vma->vm_start), (uint64)uapp - PA2VA_OFFSET, (uint64)PGSIZE, 23);
    //    }
    //  }
     if(vma){
        //3. 分配一个页，将这个页映射到对应的用户地址空间
        uint64 page = alloc_page();
        uint64 page_index = ((bad_addr - PGROUNDDOWN((uint64)(vma->vm_start))) / PGSIZE);
        uint64 page_start = PGROUNDDOWN((uint64)(vma->vm_start)) + page_index * PGSIZE;
        //4. 通过 (vma->vm_flags | VM_ANONYM) 获得当前的 VMA 是否是匿名空间
        int annom_flag = vma->vm_flags & VM_ANONYM;
        //5. 根据 VMA 匿名与否决定将新的页清零或是拷贝 uapp 中的内容
        memset(page, 0, PGSIZE);
        if(!annom_flag){
            uint64* src = (uint64*)(ramdisk_start + page_index * PGSIZE + vma->vm_content_offset_in_file);
            uint64* dst = (uint64*)(page + vma->vm_start - PGROUNDDOWN((uint64)(vma->vm_start)));
            for (int k = 0; k < PGSIZE / 8; k++) {
                dst[k] = src[k];
            }
            create_mapping(current->pgd, (uint64)page_start, (uint64)page - PA2VA_OFFSET, (uint64)PGSIZE, vma->vm_flags | 0b10001);
        }
        else{
            create_mapping(current->pgd, (uint64)page_start, (uint64)page - PA2VA_OFFSET, (uint64)PGSIZE, 23);
        }
     }
}


// arch/riscv/kernel/proc.c
void dummy() {
    // printk("Hello, I am dummy\n");
    // printk("current->pid: %d\n", current->pid);
    // printk("current->counter: %d\n", current->counter);

    schedule_test();
    uint64 MOD = 1000000007;
    uint64 auto_inc_local_var = 0;
    int last_counter = -1;
    while(1) {
        if ((last_counter == -1 || current->counter != last_counter) && current->counter > 0) {
            // if(current->counter == 1){
            //     --(current->counter);   // forced the counter to be zero if this thread is going to be scheduled
            // }                           // in case that the new counter is also 1, leading the information not printed.
            last_counter = current->counter;
            auto_inc_local_var = (auto_inc_local_var + 1) % MOD;
            printk("[PID = %d] is running. thread space begin at 0x%lx\n", current->pid, (unsigned long)current);
        }
    }
}

void schedule(){
    // printk("I am schedule\n");
#ifdef SJF
    int min_i = 0, cnt = 0;
    while(1){
        int min_counter = 1000;
        min_i = 1, cnt = 0;
        for(int i = 1; i < NR_TASKS; i++)
        {   
            if(task[i] == NULL || task[i]->counter == 0){
                cnt++;
                continue;
            }
            if(task[i]->state == TASK_RUNNING && task[i]->counter > 0 && task[i]->counter < min_counter)
            {
                min_counter = task[i]->counter;
                min_i = i;
            }
        }
        if(cnt == NR_TASKS - 1)
        {
            for(int i = 1; i < NR_TASKS; i++){
                if(task[i] == NULL)
                    continue;
                task[i]->counter = rand() % 10;
            }
        }
        else 
            break;
    }
    // printk("schedule_Next_pid: %d\n", task[min_i]->pid);
    if(min_i != 0)
        switch_to(task[min_i]);
    else
        printk("Error occured when schedule!\n");
#endif
#ifdef PRIORITY
    int c, next, i;
    while(1){
        // printk("Why you are stunned here\n");
        c = 0;
        next = 0;
        i = NR_TASKS;
        struct task_struct ** p = &task[NR_TASKS];
        while(--i > 0){
            if(task[i] == NULL)
                continue;
            // printk("pid: %d\n", task[i]->pid);
            // printk("state: %d\n", task[i]->state);
            // printk("counter: %d\n", task[i]->counter);
            if( task[i]->state == TASK_RUNNING && task[i]->counter > c)
            {
                c = (task[i])->counter;
                next = i;
            }
        }
        // printk("c: %d\n", c);
        if(c > 0) break;
        for(int j = 1; j <= NR_TASKS; j++)
            if (task[j])
                task[j]->counter = (task[j]->counter >> 1) + task[j]->priority;
    }
    // printk("next :%d\n", next);
    if(next != current->pid && next != 0)
	    switch_to(task[next]);
#endif
}



void switch_to(struct task_struct* next) {
    if(next->pid == current->pid)
        return;
    // printk("current_pid: %d\n", current->pid);
    // printk("Next_pid: %d\n", next->pid);
    printk("switch to [PID = %d COUNTER = %d]\n", next->pid, next->counter);
    //由于__switch_to只实现了上下文切换功能，所以这里需要对current指针进行更新
    struct task_struct* prev = current;
    current = next; 
        // 调用 __switch_to 进行线程切换
    __switch_to(prev, next);
}

void do_timer() {
    if(current->pid == 0)
        schedule();
    else{
        //  printk("current_pid: %d\n", current->pid);
        //  printk("current_counter: %d\n", current->counter);
        current->counter--;
        if(current->counter == 0)
            schedule();
        else{
            return;
        }
    }
}