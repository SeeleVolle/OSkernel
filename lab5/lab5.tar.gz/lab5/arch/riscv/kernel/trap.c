// trap.c 
#include "sbi.h"
#include "proc.h"
#include "printk.h"
#include "syscall.h"

void trap_handler(uint64 scause, uint64 sepc, struct pt_regs *regs) {
    
    if(scause == 0x8000000000000005)
    {   
        // printk("[S] Supervisor Mode Timer Interrupt\n");
        clock_set_next_event();
        do_timer();
    }
    //Interrupt = 0 && exception code == 8
    else if(scause == 0x0000000000000008)
    {
        // printk("[S] System call Trap, ");
        // printk("scause=: %lx, ",scause);
        // printk("stval: %lx, ", regs->stval);
        // printk("sepc: %lx\n", sepc);
        uint64 sys_call_num = regs->x[17];
        regs->sepc += 4;
        if(sys_call_num == 172 || sys_call_num == 64)
            sys_call(regs, sys_call_num);
        else{
            printk("[S] Unhandled syscall: %lx", sys_call_num);
            printk("scause=%lx__",scause);
            printk("stval: %lx, ", regs->stval);
            printk("sepc: %lx\n", sepc);
            while (1);
        }
    }
    else if(scause == 0x000000000000000c || scause == 0x000000000000000f || scause == 0x000000000000000d){
        printk("[S] Page Fault Trap, ");
        printk("scause=: %lx, ",scause);
        printk("stval: %lx, ", regs->stval);
        printk("sepc: %lx\n", sepc);
        do_page_fault(regs);
    }
    else{
        printk("[S] Unhandled trap, ");
        printk("scause=: %lx, ",scause);
        printk("stval: %lx, ", regs->stval);
        printk("sepc: %lx\n", sepc);
        while(1);
    }
    return;
}

